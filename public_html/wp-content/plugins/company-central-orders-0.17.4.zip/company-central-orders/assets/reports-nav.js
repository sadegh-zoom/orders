(function () {
	'use strict';
	var config = window.CCO_APP_CONFIG || {};
	if (!config.canViewReports || !config.reportsUrl) return;

	function reportsItem(target) {
		var item = target && target.closest ? target.closest('.ant-menu-item') : null;
		return item && item.textContent.trim() === 'گزارش‌ها' ? item : null;
	}

	function enableReportsLink() {
		document.querySelectorAll('.cco-ant-sider .ant-menu-item').forEach(function (item) {
			if (item.textContent.trim() !== 'گزارش‌ها') return;
			item.classList.remove('ant-menu-item-disabled');
			item.removeAttribute('aria-disabled');
			item.setAttribute('tabindex', '0');
			item.setAttribute('title', 'گزارش‌ها');
			item.style.cursor = 'pointer';
		});
	}

	document.addEventListener('click', function (event) {
		if (!reportsItem(event.target)) return;
		event.preventDefault();
		event.stopImmediatePropagation();
		window.location.assign(config.reportsUrl);
	}, true);

	document.addEventListener('keydown', function (event) {
		if ((event.key !== 'Enter' && event.key !== ' ') || !reportsItem(event.target)) return;
		event.preventDefault();
		window.location.assign(config.reportsUrl);
	}, true);

	var observer = new MutationObserver(enableReportsLink);
	observer.observe(document.documentElement, { childList: true, subtree: true });
	enableReportsLink();
	window.setTimeout(function () { observer.disconnect(); enableReportsLink(); }, 5000);
}());
