(function () {
  'use strict';
  var root = document.getElementById('cco-reports-root');
  if (!root || !window.CCO_REPORTS || !CCO_REPORTS.locationsApi) return;
  var period = 'year';
  var nf = new Intl.NumberFormat('fa-IR');
  var esc = function (v) { var d=document.createElement('div'); d.textContent=String(v==null?'':v); return d.innerHTML; };
  var provinces = [
    ['آذربایجان غربی',13,17],['آذربایجان شرقی',22,13],['اردبیل',30,10],['گیلان',39,13],['مازندران',49,14],['گلستان',61,15],
    ['کردستان',18,29],['زنجان',29,25],['قزوین',37,25],['البرز',44,24],['تهران',49,27],['سمنان',60,27],['خراسان شمالی',72,23],['خراسان رضوی',82,30],
    ['کرمانشاه',14,40],['همدان',27,37],['مرکزی',38,38],['قم',46,38],['اصفهان',49,49],['خراسان جنوبی',75,47],
    ['ایلام',12,52],['لرستان',27,49],['چهارمحال و بختیاری',38,55],['یزد',59,55],
    ['خوزستان',22,64],['کهگیلویه و بویراحمد',36,65],['فارس',46,70],['کرمان',65,68],['سیستان و بلوچستان',83,69],
    ['بوشهر',37,78],['هرمزگان',62,82]
  ];
  function url(province) { var q=new URLSearchParams({period:period}); if(province)q.set('province',province); return CCO_REPORTS.locationsUrl+'?'+q; }
  function tabs() { return '<div class="geo-tabs">'+[['year','سال جاری'],['month','ماه جاری'],['week','هفته جاری'],['day','دیروز'],['today','امروز']].map(function(x){return '<button data-geo-period="'+x[0]+'" class="'+(period===x[0]?'active':'')+'">'+x[1]+'</button>';}).join('')+'</div>'; }
  function render(data) {
    var holder=root.querySelector('#cco-geography-section'); if(!holder)return;
    var max=Math.max.apply(null,Object.keys(data.provinces).map(function(k){return data.provinces[k];}).concat([1]));
    var nodes=provinces.map(function(p){var count=data.provinces[p[0]]||0, intensity=.16+.72*(count/max);return '<a class="iran-province" href="'+url(p[0])+'" style="--x:'+p[1]+'%;--y:'+p[2]+'%;--heat:'+intensity+'" title="'+esc(p[0])+'، '+nf.format(count)+' سفارش"><span>'+esc(p[0])+'</span><b>'+nf.format(count)+'</b></a>';}).join('');
    var cities=data.topCities.map(function(c,i){return '<a class="top-city-row" href="'+url(c.province)+'"><i>'+nf.format(i+1)+'</i><span><b>'+esc(c.city)+'</b><small>'+esc(c.province)+'</small></span><strong>'+nf.format(c.orders)+' <small>سفارش</small></strong></a>';}).join('') || '<div class="geo-empty">در این بازه سفارشی ثبت نشده است.</div>';
    holder.innerHTML='<section class="geo-panel iran-map-card"><header><div><h2>پراکندگی سفارش‌ها در ایران</h2><p>تعداد سفارش ثبت‌شده به تفکیک استان</p></div>'+tabs()+'</header><div class="iran-map"><svg viewBox="0 0 720 610" aria-hidden="true"><path d="M103 45L188 29l76 24 75-20 91 31 74 3 55 43 93 24 18 61-35 45 19 56-53 75-13 71-57 29-17 80-75 36-54-40-78 19-65-47-89-14-42-65-45-40 13-82-45-69 18-70-14-70 49-37z"/></svg>'+nodes+'<div class="iran-map-legend"><span>کم</span><i></i><span>زیاد</span></div></div><footer><span>مجموع سفارش‌های دارای آدرس: <b>'+nf.format(data.totalOrders)+'</b></span><a href="'+url('')+'">مشاهده همه شهرها ←</a></footer></section><section class="geo-panel top-cities-card"><header><div><h2>۱۰ شهر پُرخرید</h2><p>رتبه‌بندی بر اساس تعداد سفارش</p></div>'+tabs()+'</header><div class="top-city-list">'+cities+'</div><footer><a class="geo-details" href="'+url('')+'">مشاهده جزئیات همه شهرها</a></footer></section>';
    bind();
  }
  function bind(){root.querySelectorAll('[data-geo-period]').forEach(function(b){b.onclick=function(){period=b.dataset.geoPeriod;load();};});}
  function load(){var holder=root.querySelector('#cco-geography-section');if(!holder){var panels=root.querySelector('.panels');if(!panels){setTimeout(load,100);return;}holder=document.createElement('div');holder.id='cco-geography-section';holder.className='geography-grid';panels.parentNode.insertBefore(holder,panels);}holder.innerHTML='<div class="geo-loading">در حال محاسبه پراکندگی سفارش‌ها…</div>';fetch(CCO_REPORTS.locationsApi+'?period='+period,{headers:{'X-WP-Nonce':CCO_REPORTS.nonce}}).then(function(r){if(!r.ok)throw new Error();return r.json();}).then(render).catch(function(){holder.innerHTML='<div class="geo-error">دریافت گزارش استان و شهر ناموفق بود.</div>';});}
  load();
}());
