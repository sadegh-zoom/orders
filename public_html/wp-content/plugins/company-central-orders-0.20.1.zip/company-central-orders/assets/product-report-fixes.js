(function () {
	'use strict';
	var config = window.CCO_PRODUCT_REPORT || {};
	function syncPeriod() {
		var select = document.querySelector('#pr-filters [name="period"]');
		if (!select) return;
		if (!select.querySelector('[value="yesterday"]')) {
			var option = document.createElement('option');
			option.value = 'yesterday'; option.textContent = 'دیروز';
			select.insertBefore(option, select.firstChild);
		}
		if (!select.dataset.initialized) { select.value = config.period || 'yesterday'; select.dataset.initialized = '1'; }
	}
	function syncViewColumns() {
		var metric = document.querySelector('#pr-filters [name="metric"]');
		var table = document.querySelector('.pr-table-wrap table');
		if (!metric || !table) return;
		var isViews = metric.value === 'views';
		table.querySelectorAll('tr').forEach(function (row) {
			var cells = row.children;
			var quantityLabel = isViews ? 'تعداد بازدید' : 'تعداد';
			var display = isViews ? 'none' : '';
			if (cells[3] && row.parentElement.tagName === 'THEAD' && cells[3].textContent !== quantityLabel) cells[3].textContent = quantityLabel;
			if (cells[4] && cells[4].style.display !== display) cells[4].style.display = display;
			if (cells[5] && cells[5].style.display !== display) cells[5].style.display = display;
		});
	}
	function sync() { syncPeriod(); syncViewColumns(); }
	new MutationObserver(sync).observe(document.documentElement, { childList:true, subtree:true });
	document.addEventListener('change', function (event) { if (event.target && event.target.name === 'metric') setTimeout(syncViewColumns, 0); });
	sync();
}());
